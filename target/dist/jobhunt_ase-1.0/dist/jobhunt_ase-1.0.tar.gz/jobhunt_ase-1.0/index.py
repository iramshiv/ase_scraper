from src.main.userfunctions.user_input import main

main()
